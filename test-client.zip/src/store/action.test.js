import reducer from './userreducer';
import * as actionTypes from './action';

describe('todos reducer', () => {
    if (actionTypes.USERDATALOADING) {
        it('should return the initial state', () => {
            expect(reducer(undefined, {})).toEqual(
                {
                    loading: false,
                    userdata: [],
                    error: { isError: false, errorData: undefined }
                }
            )
        })
    }
})